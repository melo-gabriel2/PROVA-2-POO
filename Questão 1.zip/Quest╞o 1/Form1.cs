﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void rbCaminhao_CheckedChanged(object sender, EventArgs e)
        {
            btCadastrar.Enabled = true;
            tbAltera.Visible = true;
            lbAltera.Visible = true;
            lbAltera.Text = "Qtd Eixos";
            pcbImagem.Image = Properties.Resources.caminhao;
            pcbImagem.Visible = true;
        }

        private void lbAssentos_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void rbOnibus_CheckedChanged_1(object sender, EventArgs e)
        {
            btCadastrar.Enabled = true;
            tbAltera.Visible = true;
            lbAltera.Visible = true;
            lbAltera.Text = "Qtd Assentos";
            pcbImagem.Image = Properties.Resources.onibus;
            pcbImagem.Visible = true;
        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {
            if (!mtbPlaca.MaskFull)
            {
                MessageBox.Show("Você deve preencher o campo: Placa!");
            }
            else if (tbAno.Text == "")
            {
                MessageBox.Show("Você deve preencher o campo: Ano!");
            }
            else if (tbAltera.Text == ""  && rbOnibus.Checked == true)
            {
               MessageBox.Show("Você deve preencher o campo: Qtd Assentos!");
            }
            else if (tbAltera.Text == "" && rbCaminhao.Checked == true)
            {
                MessageBox.Show("Você deve preencher o campo: Qtd Eixos!");
            }
            else
            {
                string[] veiculos = new string[5];
                if (rbOnibus.Checked == true)
                {
                    onibus onibus = new onibus(mtbPlaca.Text, Convert.ToInt32(tbAno.Text), Convert.ToInt32(tbAltera.Text));
                    veiculos[0] = Convert.ToString(onibus.Placa);
                    veiculos[1] = Convert.ToString(onibus.Ano);
                    veiculos[2] = Convert.ToString(onibus.Assentos);
                    veiculos[3] = "";
                    veiculos[4] = "R$" + Convert.ToString(onibus.alugar()) + ",00";
                }
                else
                {
                    caminhao caminhao = new caminhao(mtbPlaca.Text, Convert.ToInt32(tbAno.Text), Convert.ToInt32(tbAltera.Text));
                    veiculos[0] = Convert.ToString(caminhao.Placa);
                    veiculos[1] = Convert.ToString(caminhao.Ano);
                    veiculos[2] = "";
                    veiculos[3] = Convert.ToString(caminhao.Eixos);
                    veiculos[4] = "R$" + Convert.ToString(caminhao.alugar()) + ",00";

                }

                ListViewItem l = new ListViewItem(veiculos);
                lvVeiculos.Items.Add(l);
                limpar();
                rbCaminhao.Checked = false;
                rbOnibus.Checked = false;
                pcbImagem.Visible = false;
                tbAltera.Visible = false;
                lbAltera.Visible = false;
                btCadastrar.Enabled = false;
            }
        }

        private void limpar()
        {
            mtbPlaca.Clear();
            tbAno.Clear();
            tbAltera.Clear();
        }
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void mtbPlaca_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void lvVeiculos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void tbEixos_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void pcbOnibus_Click(object sender, EventArgs e)
        {
            
        }

        private void pcbCaminhao_Click(object sender, EventArgs e)
        {
            
        }

        private void btLimpar_Click(object sender, EventArgs e)
        {
            limpar();
        }
    }
}
