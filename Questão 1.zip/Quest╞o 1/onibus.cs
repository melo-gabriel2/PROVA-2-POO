﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    internal class onibus : veiculos
    {
        private int assentos;

        public onibus(string _placa, int _ano, int _assentos) : base(_placa, _ano)
        {
            this.assentos = _assentos;
            this.Placa = _placa;
            this.Ano = _ano;
        }

        override public double alugar()
        {
            double diaria = (30 * this.assentos) - ((2024 - this.ano) * 70);
            return diaria;
        }
        public int Assentos { get => assentos; set => assentos = value; }
    }

    
    
}
