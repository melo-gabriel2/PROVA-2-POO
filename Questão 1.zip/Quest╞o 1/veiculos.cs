﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    abstract class veiculos
    {
        protected string placa;
        protected int ano;

        public veiculos(string _placa, int _ano)
        {
            this.placa = _placa;
            this.ano = _ano;
        }

        abstract public double alugar();

        public string Placa { get => placa; set => placa = value; }
        public int Ano { get => ano; set => ano = value; }
    }


}
