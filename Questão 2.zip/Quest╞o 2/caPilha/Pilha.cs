﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caPilha
{
    internal class Pilha
    {
        private Stack<string> pecas;

        public Pilha()
        {
            pecas = new Stack<string>();
        }

        public void AdicionarPeca(string peca)
        {
            pecas.Push(peca);
        }

        public void TrocarPeca(string pecaAntiga)
        {
            Stack<string> tempStack = new Stack<string>();
            bool pecaEncontrada = false;

            Console.WriteLine("\nProcesso de desempilhamento:");

            while (pecas.Count > 0)
            {
                string pecaAtual = pecas.Pop();
                Console.WriteLine($"Desempilhando: {pecaAtual}");

                if (pecaAtual.Equals(pecaAntiga, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine($"Peça '{pecaAntiga}' encontrada e será substituída.");
                    tempStack.Push($"Nova {pecaAtual}");
                    pecaEncontrada = true;
                    break;
                }
                else
                {
                    tempStack.Push(pecaAtual);
                }
            }

            Console.WriteLine("\nProcesso de empilhamento:");
            Stack<string> reversedStack = new Stack<string>();
            while (tempStack.Count > 0)
            {
                string peca = tempStack.Pop();
                reversedStack.Push(peca);
            }
            while (reversedStack.Count > 0)
            {
                string peca = reversedStack.Pop();
                Console.WriteLine($"Empilhando: {peca}");
                pecas.Push(peca);
            }

            if (pecaEncontrada)
            {
                Console.WriteLine($"\nA peça '{pecaAntiga}' foi substituída por 'Nova {pecaAntiga}'.");
            }
            else
            {
                Console.WriteLine($"\nA peça '{pecaAntiga}' não foi encontrada na pilha.");
            }

            Console.WriteLine("\nNova pilha de cima para baixo:");
            List<string> pilhaFinal = new List<string>(pecas);
            pilhaFinal.Reverse();
            foreach (var peca in pilhaFinal)
            {
                Console.WriteLine(peca);
            }
        }

        public void ExibirPecas()
        {
            Console.WriteLine("Peças na pilha:");
            foreach (var peca in pecas)
            {
                Console.WriteLine(peca);
            }
        }
    }
}
