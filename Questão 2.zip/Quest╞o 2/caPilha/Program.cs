﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caPilha
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Pilha pilha = new Pilha();

            pilha.AdicionarPeca("Cúpula de Vidro");
            pilha.AdicionarPeca("Lâmpada");
            pilha.AdicionarPeca("Hélice");
            pilha.AdicionarPeca("Suporte de Teto");

            Console.WriteLine("Estado inicial da pilha:");
            pilha.ExibirPecas();

            Console.Write("\nDigite o nome da peça a ser trocada: ");
            string pecaParaTrocar = Console.ReadLine();

            pilha.TrocarPeca(pecaParaTrocar);
            Console.ReadLine();
        }
    }
}
