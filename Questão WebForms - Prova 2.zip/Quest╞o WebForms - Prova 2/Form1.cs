﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void rbCaminhao_CheckedChanged(object sender, EventArgs e)
        {
            tbAssentos.Visible = false;
            tbEixos.Visible = true;
            lbAssentos.Visible = true;
            lbAssentos.Text = "Qtd Eixos";
            pcbCaminhao.Visible = true;
            pcbOnibus.Visible = false;
        }

        private void lbAssentos_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void rbOnibus_CheckedChanged_1(object sender, EventArgs e)
        {
            tbAssentos.Visible = true;
            tbEixos.Visible = false;
            lbAssentos.Visible = true;
            lbAssentos.Text = "Qtd Assentos";
            pcbCaminhao.Visible = false;
            pcbOnibus.Visible = true;
        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {
            if (!mtbPlaca.MaskFull)
            {
                MessageBox.Show("Você deve preencher o campo: Placa");
            }
            else if (tbAno.Text == "")
            {
                MessageBox.Show("Você deve preencher o campo: Ano");
            }
            else if (tbAssentos.Text == ""  && rbOnibus.Checked == true)
            {
               MessageBox.Show("Você deve preencher o campo: Qtd Assentos");
            }
            else if (tbEixos.Text == "" && rbCaminhao.Checked == true)
            {
                MessageBox.Show("Você deve preencher o campo: Qtd Eixos");
            }
            else
            {
                string[] veiculos = new string[5];
                veiculos[0] = mtbPlaca.Text;
                veiculos[1] = tbAno.Text;
                veiculos[2] = tbAssentos.Text;
                veiculos[3] = tbEixos.Text;
                veiculos[4] = diaria();
                ListViewItem l = new ListViewItem(veiculos);
                lvVeiculos.Items.Add(l);
                limpar();
                tbEixos.Visible = false;
                tbAssentos.Visible = false;
                lbAssentos.Visible = false;
                rbCaminhao.Checked = false;
                rbOnibus.Checked = false;
                pcbCaminhao.Visible = false;
                pcbOnibus.Visible = false;
            }
        }

        private string diaria()
        {
            if(rbCaminhao.Checked == true)
            {
                return "R$720,00";
            }
            else
            {
                return "R$2550,00";
            }
        }
        private void limpar()
        {
            mtbPlaca.Clear();
            tbAno.Clear();
            tbAssentos.Clear();
            tbEixos.Clear();
        }
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void mtbPlaca_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void lvVeiculos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void tbEixos_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void pcbOnibus_Click(object sender, EventArgs e)
        {
            
        }

        private void pcbCaminhao_Click(object sender, EventArgs e)
        {
            
        }

        private void btLimpar_Click(object sender, EventArgs e)
        {
            limpar();
        }
    }
}
