﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mtbPlaca = new System.Windows.Forms.MaskedTextBox();
            this.tbAltera = new System.Windows.Forms.TextBox();
            this.tbAno = new System.Windows.Forms.TextBox();
            this.rbOnibus = new System.Windows.Forms.RadioButton();
            this.rbCaminhao = new System.Windows.Forms.RadioButton();
            this.lbPlaca = new System.Windows.Forms.Label();
            this.lbAno = new System.Windows.Forms.Label();
            this.lbAltera = new System.Windows.Forms.Label();
            this.btCadastrar = new System.Windows.Forms.Button();
            this.btLimpar = new System.Windows.Forms.Button();
            this.lvVeiculos = new System.Windows.Forms.ListView();
            this.colPlaca = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAno = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAssentos = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEixos = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDiaria = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pcbImagem = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pcbImagem)).BeginInit();
            this.SuspendLayout();
            // 
            // mtbPlaca
            // 
            this.mtbPlaca.Location = new System.Drawing.Point(211, 92);
            this.mtbPlaca.Mask = "AAA-0000";
            this.mtbPlaca.Name = "mtbPlaca";
            this.mtbPlaca.Size = new System.Drawing.Size(100, 20);
            this.mtbPlaca.TabIndex = 0;
            this.mtbPlaca.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mtbPlaca_MaskInputRejected);
            // 
            // tbAltera
            // 
            this.tbAltera.Location = new System.Drawing.Point(211, 173);
            this.tbAltera.Name = "tbAltera";
            this.tbAltera.Size = new System.Drawing.Size(100, 20);
            this.tbAltera.TabIndex = 1;
            this.tbAltera.Visible = false;
            this.tbAltera.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // tbAno
            // 
            this.tbAno.Location = new System.Drawing.Point(211, 131);
            this.tbAno.Name = "tbAno";
            this.tbAno.Size = new System.Drawing.Size(100, 20);
            this.tbAno.TabIndex = 2;
            // 
            // rbOnibus
            // 
            this.rbOnibus.AutoSize = true;
            this.rbOnibus.Location = new System.Drawing.Point(95, 56);
            this.rbOnibus.Name = "rbOnibus";
            this.rbOnibus.Size = new System.Drawing.Size(58, 17);
            this.rbOnibus.TabIndex = 3;
            this.rbOnibus.TabStop = true;
            this.rbOnibus.Text = "Ônibus";
            this.rbOnibus.UseVisualStyleBackColor = true;
            this.rbOnibus.CheckedChanged += new System.EventHandler(this.rbOnibus_CheckedChanged_1);
            // 
            // rbCaminhao
            // 
            this.rbCaminhao.AutoSize = true;
            this.rbCaminhao.Location = new System.Drawing.Point(177, 56);
            this.rbCaminhao.Name = "rbCaminhao";
            this.rbCaminhao.Size = new System.Drawing.Size(72, 17);
            this.rbCaminhao.TabIndex = 4;
            this.rbCaminhao.TabStop = true;
            this.rbCaminhao.Text = "Caminhão";
            this.rbCaminhao.UseVisualStyleBackColor = true;
            this.rbCaminhao.CheckedChanged += new System.EventHandler(this.rbCaminhao_CheckedChanged);
            // 
            // lbPlaca
            // 
            this.lbPlaca.AutoSize = true;
            this.lbPlaca.Location = new System.Drawing.Point(118, 95);
            this.lbPlaca.Name = "lbPlaca";
            this.lbPlaca.Size = new System.Drawing.Size(34, 13);
            this.lbPlaca.TabIndex = 5;
            this.lbPlaca.Text = "Placa";
            this.lbPlaca.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbAno
            // 
            this.lbAno.AutoSize = true;
            this.lbAno.Location = new System.Drawing.Point(118, 134);
            this.lbAno.Name = "lbAno";
            this.lbAno.Size = new System.Drawing.Size(26, 13);
            this.lbAno.TabIndex = 6;
            this.lbAno.Text = "Ano";
            this.lbAno.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lbAltera
            // 
            this.lbAltera.AutoSize = true;
            this.lbAltera.Location = new System.Drawing.Point(118, 173);
            this.lbAltera.Name = "lbAltera";
            this.lbAltera.Size = new System.Drawing.Size(70, 13);
            this.lbAltera.TabIndex = 7;
            this.lbAltera.Text = "Qtd Assentos";
            this.lbAltera.Visible = false;
            this.lbAltera.Click += new System.EventHandler(this.lbAssentos_Click);
            // 
            // btCadastrar
            // 
            this.btCadastrar.Enabled = false;
            this.btCadastrar.Location = new System.Drawing.Point(113, 210);
            this.btCadastrar.Name = "btCadastrar";
            this.btCadastrar.Size = new System.Drawing.Size(75, 23);
            this.btCadastrar.TabIndex = 8;
            this.btCadastrar.Text = "Cadastrar";
            this.btCadastrar.UseVisualStyleBackColor = true;
            this.btCadastrar.Click += new System.EventHandler(this.btCadastrar_Click);
            // 
            // btLimpar
            // 
            this.btLimpar.Location = new System.Drawing.Point(236, 210);
            this.btLimpar.Name = "btLimpar";
            this.btLimpar.Size = new System.Drawing.Size(75, 23);
            this.btLimpar.TabIndex = 9;
            this.btLimpar.Text = "Limpar";
            this.btLimpar.UseVisualStyleBackColor = true;
            this.btLimpar.Click += new System.EventHandler(this.btLimpar_Click);
            // 
            // lvVeiculos
            // 
            this.lvVeiculos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colPlaca,
            this.colAno,
            this.colAssentos,
            this.colEixos,
            this.colDiaria});
            this.lvVeiculos.FullRowSelect = true;
            this.lvVeiculos.HideSelection = false;
            this.lvVeiculos.Location = new System.Drawing.Point(36, 253);
            this.lvVeiculos.MultiSelect = false;
            this.lvVeiculos.Name = "lvVeiculos";
            this.lvVeiculos.Size = new System.Drawing.Size(335, 185);
            this.lvVeiculos.TabIndex = 11;
            this.lvVeiculos.UseCompatibleStateImageBehavior = false;
            this.lvVeiculos.View = System.Windows.Forms.View.Details;
            this.lvVeiculos.SelectedIndexChanged += new System.EventHandler(this.lvVeiculos_SelectedIndexChanged);
            // 
            // colPlaca
            // 
            this.colPlaca.Text = "Placa";
            this.colPlaca.Width = 85;
            // 
            // colAno
            // 
            this.colAno.Text = "Ano";
            this.colAno.Width = 69;
            // 
            // colAssentos
            // 
            this.colAssentos.Text = "Assentos";
            // 
            // colEixos
            // 
            this.colEixos.Text = "Eixos";
            // 
            // colDiaria
            // 
            this.colDiaria.Text = "Diária";
            this.colDiaria.Width = 97;
            // 
            // pcbImagem
            // 
            this.pcbImagem.Location = new System.Drawing.Point(356, 70);
            this.pcbImagem.Name = "pcbImagem";
            this.pcbImagem.Size = new System.Drawing.Size(287, 177);
            this.pcbImagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbImagem.TabIndex = 13;
            this.pcbImagem.TabStop = false;
            this.pcbImagem.Visible = false;
            this.pcbImagem.Click += new System.EventHandler(this.pcbCaminhao_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 635);
            this.Controls.Add(this.pcbImagem);
            this.Controls.Add(this.lvVeiculos);
            this.Controls.Add(this.btLimpar);
            this.Controls.Add(this.btCadastrar);
            this.Controls.Add(this.lbAltera);
            this.Controls.Add(this.lbAno);
            this.Controls.Add(this.lbPlaca);
            this.Controls.Add(this.rbCaminhao);
            this.Controls.Add(this.rbOnibus);
            this.Controls.Add(this.tbAno);
            this.Controls.Add(this.tbAltera);
            this.Controls.Add(this.mtbPlaca);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pcbImagem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mtbPlaca;
        private System.Windows.Forms.TextBox tbAltera;
        private System.Windows.Forms.TextBox tbAno;
        private System.Windows.Forms.RadioButton rbOnibus;
        private System.Windows.Forms.RadioButton rbCaminhao;
        private System.Windows.Forms.Label lbPlaca;
        private System.Windows.Forms.Label lbAno;
        private System.Windows.Forms.Label lbAltera;
        private System.Windows.Forms.Button btCadastrar;
        private System.Windows.Forms.Button btLimpar;
        private System.Windows.Forms.ListView lvVeiculos;
        private System.Windows.Forms.ColumnHeader colPlaca;
        private System.Windows.Forms.ColumnHeader colAno;
        private System.Windows.Forms.ColumnHeader colAssentos;
        private System.Windows.Forms.ColumnHeader colEixos;
        private System.Windows.Forms.ColumnHeader colDiaria;
        private System.Windows.Forms.PictureBox pcbImagem;
    }
}

