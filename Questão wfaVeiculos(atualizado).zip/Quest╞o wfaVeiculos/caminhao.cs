﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    internal class caminhao : veiculos
    {
        private int eixos;

        public caminhao(string _placa, int _ano, int _eixos) : base(_placa,_ano)
        {
            this.eixos = _eixos;
            this.Placa = _placa;
            this.Ano = _ano;
        }

        public int Eixos { get => eixos; set => eixos = value; }

        override public string diaria()
        {
            return "R$2550,00";
        }
        
    }
}
